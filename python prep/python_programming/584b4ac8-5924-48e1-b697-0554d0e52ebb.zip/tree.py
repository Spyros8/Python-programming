class BinarySearchTree:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left_child = left
        self.right_child = right


class BinarySearchTreeBuilder:
    def insert(self, value, node):
        if value <= node.value:
            if node.left_child is not None:
                # Recursively traverse left child until leaf node
                self.insert(value, node.left_child)
            else:
                # Is leaf node. Add new value as left child
                node.left_child = BinarySearchTree(value)
        else:
            if node.right_child is not None:
                # Recursively traverse right child until leaf node
                self.insert(value, node.right_child)
            else:
                # is leaf node. Add new value as right child
                node.right_child = BinarySearchTree(value)


class BinarySearchTreeFinder:
    def find(self, query, node):
        if query == node.value:
            return True
        elif query <= node.value:
            if node.left_child is not None:
                # Recursively traverse left child
                return self.find(query, node.left_child)
            else:
                # Is leaf node. So query not found.
                return False
        else:
            if node.right_child is not None:
                # Recursively traverse right child
                return self.find(query, node.right_child)
            else:
                # Is leaf node. So query not found.
                return False


class BinarySearchTreeWalker:
    def preorder(self, node):
        if node.left_child is not None:
            self.preorder(node.left_child)
        
        print(node.value)
        
        if node.right_child is not None:
            self.preorder(node.right_child)
            

def build_bst(numbers):
    builder = BinarySearchTreeBuilder()
    tree = BinarySearchTree(numbers[0])
    for number in numbers[1:]:
        builder.insert(number, tree)
    return tree


def query_correct(tree, numbers):
    finder = BinarySearchTreeFinder()
    for number in numbers:
        assert finder.find(number, tree) == True
        
        
def query_incorrect(tree, numbers):
    finder = BinarySearchTreeFinder()
    for number in numbers:
        assert finder.find(number, tree) == False


def traverse(tree):
    walker = BinarySearchTreeWalker()
    walker.preorder(tree)


def test():
    numbers = [50, 69, 54, 27, 15, 79, 24, 18, 9, 45, 72, 25]
    tree = build_bst(numbers)
    query_correct(tree, numbers)
    
    incorrect_numbers = [8, 80, 22, 65, 0, 53]
    query_incorrect(tree, incorrect_numbers)
    
    traverse(tree)
    
    
if __name__ == "__main__":
    test()

