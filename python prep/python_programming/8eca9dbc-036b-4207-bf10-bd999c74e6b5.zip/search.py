def sequential_search(query, items):
    for (position, item) in enumerate(items):
        if item == query:
            return True

    return False


def binary_search_recursive(query, items):
    if len(items) == 1:
        return items[0] == query
    else:
        middle = round((len(items)-1)/2)
        if items[middle] == query:
            return True
        elif query < items[middle]:
            return binary_search_recursive(query, items[:middle])
        else:
            return binary_search_recursive(query, items[middle+1:])


def binary_search_iterative(query, items):
    left = 0
    right = len(items) - 1

    while left <= right: 
        middle = round(left + (right-left)/2)
        
        if query == items[middle]:
            return True
        elif query < items[middle]:
            right = middle - 1
        else:
            left = middle + 1
    
    return False


def test_sequential_search():
    numbers = [2, 17, 29, 38, 46, 51, 55, 72, 83, 91, 95]
    print(sequential_search(42, numbers))
    print(sequential_search(17, numbers))


def test_binary_search_recursive():
    numbers = [2, 17, 29, 38, 46, 51, 55, 72, 83, 91, 95]
    print(binary_search_recursive(42, numbers))
    print(binary_search_recursive(17, numbers))


def test_binary_search_iterative():
    numbers = [2, 17, 29, 38, 46, 51, 55, 72, 83, 91, 95]
    print(binary_search_iterative(42, numbers))
    print(binary_search_iterative(2, numbers))


if __name__ == "__main__":
    #test_sequential_search()
    #test_binary_search_recursive()
    test_binary_search_iterative()
