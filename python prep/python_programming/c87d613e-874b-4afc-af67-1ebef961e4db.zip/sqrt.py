""" Optimising the square root estimator.

Here is my optimised version as discussed in the lecture.
(Not fully checked for correctness!)

Author: Josiah Wang
"""

n = float(input("Please enter a positive number: "))

tolerance = 0.0001

# estimate root at integer level
root = 1
while root * root < n:
    root += 1

# iteratively reduce search by precision
step_size = 1
while abs(root*root - n) > tolerance:
    root = root - step_size
    step_size = step_size * 0.1
    while root * root < n:
        root += step_size
        
print(root)
