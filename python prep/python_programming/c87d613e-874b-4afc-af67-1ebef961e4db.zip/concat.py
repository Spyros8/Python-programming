""" String concatenation.

Author: Josiah Wang
"""

import timeit

setup_string = 'items = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]'

strconcat_code = '''s=""
for item in items:
    s += item
'''

join_code = 's = "".join(items)'


n = timeit.timeit(strconcat_code, setup=setup_string)
print(n)

n = timeit.timeit(join_code, setup=setup_string)
print(n)

