""" List comprehension.

Author: Josiah Wang
"""

import timeit

setup_string = 'items = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]'

loop_code = '''
s = []
for item in items:
    s.append(item)
'''

comprehension_code = 's = [item for item in items]'


n = timeit.timeit(loop_code, setup=setup_string)
print(n)

n = timeit.timeit(comprehension_code, setup=setup_string)
print(n)

