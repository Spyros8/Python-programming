""" Filtering lists to a list with only unique values

Author: Josiah Wang
"""

import random
import timeit
from itertools import permutations


def stringify(seq):
    return "".join(map(str, seq))


def generate_list(list_size, string_size, seed=7777):
    """ Generate list of list_size, string_size, 
        where each element is a string representation of a number of width string_size 
        Ends up with about 58-60% of items in the list being unique
    """

    random.seed(seed) # Use seed number for reproducibility

    # generate population of strings of length string_size 
    population = list(map(stringify, permutations(range(1,10), string_size)))    # nPk
    
    # select random subset of population (of 80-90% of list_size)
    n = round(random.uniform(0.8, 0.9) * list_size)
    random.shuffle(population)
    population = population[:n]
    
    # select random from population with replacement 
    return random.choices(population, k=list_size)


def wrapper(func, *args, **kwargs):
    """ Wrapper so that I can call functions with arguments
        in timeit.timeit()
        https://www.pythoncentral.io/time-a-python-function/
    """
    def wrapped():
        return func(*args, **kwargs)
    return wrapped


def filter_with_list(items):
    """ Check list one at a time
    """
    filtered_items = []

    for item in items:
        if item not in filtered_items:
            filtered_items.append(item)

    return filtered_items


def filter_with_set(items):
    """ Use set to filter (and cast back to list)
    """
    return list(set(items))


def filter_with_dict(items):
    """ Use dictionaries to filter (and cast keys to list)
    """
    return list(dict(zip(items, [None] * len(items))))





trials = 1

functions = [filter_with_list, filter_with_dict, filter_with_set]
list_sizes = [10, 100, 600, 4500, 30000]

for i in range(trials):
    for list_size in list_sizes:
        # generate number list
        seed = random.randint(1, 1000)
        x = generate_list(list_size, 3, seed)

        # run profiling for each function with this new list  
        for j, function in enumerate(functions):
            wrapped = wrapper(function, x)
            n = timeit.timeit(wrapped, number=1000)
            print(f"{function}, list size {list_size}, {n:.5} seconds")

